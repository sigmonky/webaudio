pKey0 = new Object;
pKey0.kbKey = 'z';
pKey0.flag = true;
pKey0.value = '#1A';
pKey0.sound = 'tone-1A';

pKey1 = new Object;
pKey1.kbKey = 's';
pKey1.flag = true;
pKey1.value = '#1As';
pKey1.sound = 'tone-1As';

pKey2 = new Object;
pKey2.kbKey = 'x';
pKey2.flag = true;
pKey2.value = '#1B';
pKey2.sound = 'tone-1B';

pKey3 = new Object;
pKey3.kbKey = 'c';
pKey3.flag = true;
pKey3.value = '#2C';
pKey3.sound = 'tone-2C';

pKey4 = new Object;
pKey4.kbKey = 'f';
pKey4.flag = true;
pKey4.value = '#2Cs';
pKey4.sound = 'tone-2Cs';

pKey5 = new Object;
pKey5.kbKey = 'v';
pKey5.flag = true;
pKey5.value = '#2D';
pKey5.sound = 'tone-2D';

pKey6 = new Object;
pKey6.kbKey = 'g';
pKey6.flag = true;
pKey6.value = '#2Ds';
pKey6.sound = 'tone-2Ds';

pKey7 = new Object;
pKey7.kbKey = 'b';
pKey7.flag = true;
pKey7.value = '#2E';
pKey7.sound = 'tone-2E';

pKey8 = new Object;
pKey8.kbKey = 'n';
pKey8.flag = true;
pKey8.value = '#2F';
pKey8.sound = 'tone-2F';

pKey9 = new Object;
pKey9.kbKey = 'j';
pKey9.flag = true;
pKey9.value = '#2Fs';
pKey9.sound = 'tone-2Fs';

pKey10 = new Object;
pKey10.kbKey = 'm';
pKey10.flag = true;
pKey10.value = '#2G';
pKey10.sound = 'tone-2G';

pKey11 = new Object;
pKey11.kbKey = 'k 1';
pKey11.flag = true;
pKey11.value = '#2Gs';
pKey11.sound = 'tone-2Gs';

pKey12 = new Object;
pKey12.kbKey = ', q';
pKey12.flag = true;
pKey12.value = '#2A';
pKey12.sound = 'tone-2A';

pKey13 = new Object;
pKey13.kbKey = 'l 2';
pKey13.flag = true;
pKey13.value = '#2As';
pKey13.sound = 'tone-2As';

pKey14 = new Object;
pKey14.kbKey = '. w';
pKey14.flag = true;
pKey14.value = '#2B';
pKey14.sound = 'tone-2B';

pKey15 = new Object;
pKey15.kbKey = 'e';
pKey15.flag = true;
pKey15.value = '#3C';
pKey15.sound = 'tone-3C';

pKey16 = new Object;
pKey16.kbKey = '4';
pKey16.flag = true;
pKey16.value = '#3Cs';
pKey16.sound = 'tone-3Cs';

pKey17 = new Object;
pKey17.kbKey = 'r';
pKey17.flag = true;
pKey17.value = '#3D';
pKey17.sound = 'tone-3D';

pKey18 = new Object;
pKey18.kbKey = '5';
pKey18.flag = true;
pKey18.value = '#3Ds';
pKey18.sound = 'tone-3Ds';

pKey19 = new Object;
pKey19.kbKey = 't';
pKey19.flag = true;
pKey19.value = '#3E';
pKey19.sound = 'tone-3E';

pKey20 = new Object;
pKey20.kbKey = 'y';
pKey20.flag = true;
pKey20.value = '#3F';
pKey20.sound = 'tone-3F';

pKey21 = new Object;
pKey21.kbKey = '7';
pKey21.flag = true;
pKey21.value = '#3Fs';
pKey21.sound = 'tone-3Fs';

pKey22 = new Object;
pKey22.kbKey = 'u';
pKey22.flag = true;
pKey22.value = '#3G';
pKey22.sound = 'tone-3G';

pKey23 = new Object;
pKey23.kbKey = '8';
pKey23.flag = true;
pKey23.value = '#3Gs';
pKey23.sound = 'tone-3Gs';

pKey24 = new Object;
pKey24.kbKey = 'i';
pKey24.flag = true;
pKey24.value = '#3A';
pKey24.sound = 'tone-3A';

pKey25 = new Object;
pKey25.kbKey = '9';
pKey25.flag = true;
pKey25.value = '#3As';
pKey25.sound = 'tone-3As';

pKey26 = new Object;
pKey26.kbKey = 'o';
pKey26.flag = true;
pKey26.value = '#3B';
pKey26.sound = 'tone-3B';

pKey27 = new Object;
pKey27.kbKey = 'p';
pKey27.flag = true;
pKey27.value = '#4C';
pKey27.sound = 'tone-4C';