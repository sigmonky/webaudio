pKey0 = new Object;
pKey0.kbKey = 'z';
pKey0.flag = true;
pKey0.value = '#1A';
pKey0.sound = 'tone-1A';

pKey1 = new Object;
pKey1.kbKey = 's';
pKey1.flag = true;
pKey1.value = '#1As';
pKey1.sound = 'tone-1As';

pKey2 = new Object;
pKey2.kbKey = 'x';
pKey2.flag = true;
pKey2.value = '#1B';
pKey2.sound = 'tone-1B';

pKey3 = new Object;
pKey3.kbKey = 'c';
pKey3.flag = true;
pKey3.value = '#2C';
pKey3.sound = 'tone-2C';

pKey4 = new Object;
pKey4.kbKey = 'f';
pKey4.flag = true;
pKey4.value = '#2Cs';
pKey4.sound = 'tone-2Cs';

pKey5 = new Object;
pKey5.kbKey = 'v';
pKey5.flag = true;
pKey5.value = '#2D';
pKey5.sound = 'tone-2D';

pKey6 = new Object;
pKey6.kbKey = 'g';
pKey6.flag = true;
pKey6.value = '#2Ds';
pKey6.sound = 'tone-2Ds';

pKey7 = new Object;
pKey7.kbKey = 'b';
pKey7.flag = true;
pKey7.value = '#2E';
pKey7.sound = 'tone-2E';

pKey8 = new Object;
pKey8.kbKey = 'n';
pKey8.flag = true;
pKey8.value = '#2F';
pKey8.sound = 'tone-2F';

pKey9 = new Object;
pKey9.kbKey = 'j';
pKey9.flag = true;
pKey9.value = '#2Fs';
pKey9.sound = 'tone-2Fs';

pKey10 = new Object;
pKey10.kbKey = 'm';
pKey10.flag = true;
pKey10.value = '#2G';
pKey10.sound = 'tone-2G';

pKey11 = new Object;
pKey11.kbKey = 'k 1';
pKey11.flag = true;
pKey11.value = '#2Gs';
pKey11.sound = 'tone-2Gs';

pKey12 = new Object;
pKey12.kbKey = ', q';
pKey12.flag = true;
pKey12.value = '#2A';
pKey12.sound = 'tone-2A';

pKey13 = new Object;
pKey13.kbKey = 'l 2';
pKey13.flag = true;
pKey13.value = '#2As';
pKey13.sound = 'tone-2As';

pKey14 = new Object;
pKey14.kbKey = '. w';
pKey14.flag = true;
pKey14.value = '#2B';
pKey14.sound = 'tone-2B';

pKey15 = new Object;
pKey15.kbKey = 'e';
pKey15.flag = true;
pKey15.value = '#3C';
pKey15.sound = 'tone-3C';

pKey16 = new Object;
pKey16.kbKey = '4';
pKey16.flag = true;
pKey16.value = '#3Cs';
pKey16.sound = 'tone-3Cs';

pKey17 = new Object;
pKey17.kbKey = 'r';
pKey17.flag = true;
pKey17.value = '#3D';
pKey17.sound = 'tone-3D';

pKey18 = new Object;
pKey18.kbKey = '5';
pKey18.flag = true;
pKey18.value = '#3Ds';
pKey18.sound = 'tone-3Ds';

pKey19 = new Object;
pKey19.kbKey = 't';
pKey19.flag = true;
pKey19.value = '#3E';
pKey19.sound = 'tone-3E';

pKey20 = new Object;
pKey20.kbKey = 'y';
pKey20.flag = true;
pKey20.value = '#3F';
pKey20.sound = 'tone-3F';

pKey21 = new Object;
pKey21.kbKey = '7';
pKey21.flag = true;
pKey21.value = '#3Fs';
pKey21.sound = 'tone-3Fs';

pKey22 = new Object;
pKey22.kbKey = 'u';
pKey22.flag = true;
pKey22.value = '#3G';
pKey22.sound = 'tone-3G';

pKey23 = new Object;
pKey23.kbKey = '8';
pKey23.flag = true;
pKey23.value = '#3Gs';
pKey23.sound = 'tone-3Gs';

pKey24 = new Object;
pKey24.kbKey = 'i';
pKey24.flag = true;
pKey24.value = '#3A';
pKey24.sound = 'tone-3A';

pKey25 = new Object;
pKey25.kbKey = '9';
pKey25.flag = true;
pKey25.value = '#3As';
pKey25.sound = 'tone-3As';

pKey26 = new Object;
pKey26.kbKey = 'o';
pKey26.flag = true;
pKey26.value = '#3B';
pKey26.sound = 'tone-3B';

pKey27 = new Object;
pKey27.kbKey = 'p';
pKey27.flag = true;
pKey27.value = '#4C';
pKey27.sound = 'tone-4C';

pKey28 = new Object;
pKey28.kbKey = '';
pKey28.flag = true;
pKey28.value = '#1C';
pKey28.sound = 'tone-1C';

pKey29 = new Object;
pKey29.kbKey = '';
pKey29.flag = true;
pKey29.value = '#1C';
pKey29.sound = 'tone-1C';

pKey30 = new Object;
pKey30.kbKey = '';
pKey30.flag = true;
pKey30.value = '#0G';
pKey30.sound = 'tone-0G';

pKey31 = new Object;
pKey31.kbKey = '';
pKey31.flag = true;
pKey31.value = '#0Gs';
pKey31.sound = 'tone-0Gs';

pKey32 = new Object;
pKey32.kbKey = '';
pKey32.flag = true;
pKey32.value = '#0A';
pKey32.sound = 'tone-0A';

pKey33 = new Object;
pKey33.kbKey = '';
pKey33.flag = true;
pKey33.value = '#0As';
pKey33.sound = 'tone-0As';

pKey34 = new Object;
pKey34.kbKey = '';
pKey34.flag = true;
pKey34.value = '#0B';
pKey34.sound = 'tone-0B';

pKey35 = new Object;
pKey35.kbKey = '';
pKey35.flag = true;
pKey35.value = '#1C';
pKey35.sound = 'tone-1C';

pKey36 = new Object;
pKey36.kbKey = '';
pKey36.flag = true;
pKey36.value = '#1C';
pKey36.sound = 'tone-1C';

pKey37 = new Object;
pKey37.kbKey = '';
pKey37.flag = true;
pKey37.value = '#1C';
pKey37.sound = 'tone-1C';

pKey38 = new Object;
pKey38.kbKey = '';
pKey38.flag = true;
pKey38.value = '#1C';
pKey38.sound = 'tone-1C';

pKey39 = new Object;
pKey39.kbKey = '';
pKey39.flag = true;
pKey39.value = '#1C';
pKey39.sound = 'tone-1C';

pKey40 = new Object;
pKey40.kbKey = '';
pKey40.flag = true;
pKey40.value = '#0G';
pKey40.sound = 'tone-0G';

pKey41 = new Object;
pKey41.kbKey = '';
pKey41.flag = true;
pKey41.value = '#0Gs';
pKey41.sound = 'tone-0Gs';

pKey42 = new Object;
pKey42.kbKey = '';
pKey42.flag = true;
pKey42.value = '#0A';
pKey42.sound = 'tone-0A';

pKey43 = new Object;
pKey43.kbKey = '';
pKey43.flag = true;
pKey43.value = '#0As';
pKey43.sound = 'tone-0As';

pKey44 = new Object;
pKey44.kbKey = '';
pKey44.flag = true;
pKey44.value = '#0B';
pKey44.sound = 'tone-0B';

pKey45 = new Object;
pKey45.kbKey = '';
pKey45.flag = true;
pKey45.value = '#1C';
pKey45.sound = 'tone-1C';

pKey46 = new Object;
pKey46.kbKey = '';
pKey46.flag = true;
pKey46.value = '#1C';
pKey46.sound = 'tone-1C';

pKey47 = new Object;
pKey47.kbKey = '';
pKey47.flag = true;
pKey47.value = '#1C';
pKey47.sound = 'tone-1C';

pKey48 = new Object;
pKey48.kbKey = '';
pKey48.flag = true;
pKey48.value = '#1C';
pKey48.sound = 'tone-1C';

pKey49 = new Object;
pKey49.kbKey = '';
pKey49.flag = true;
pKey49.value = '#1C';
pKey49.sound = 'tone-1C';

pKey50 = new Object;
pKey50.kbKey = '';
pKey50.flag = true;
pKey50.value = '#0G';
pKey50.sound = 'tone-0G';

pKey51 = new Object;
pKey51.kbKey = '';
pKey51.flag = true;
pKey51.value = '#0Gs';
pKey51.sound = 'tone-0Gs';

pKey52 = new Object;
pKey52.kbKey = '';
pKey52.flag = true;
pKey52.value = '#0A';
pKey52.sound = 'tone-0A';

pKey53 = new Object;
pKey53.kbKey = '';
pKey53.flag = true;
pKey53.value = '#0As';
pKey53.sound = 'tone-0As';

pKey54 = new Object;
pKey54.kbKey = '';
pKey54.flag = true;
pKey54.value = '#0B';
pKey54.sound = 'tone-0B';

pKey55 = new Object;
pKey55.kbKey = '';
pKey55.flag = true;
pKey55.value = '#1C';
pKey55.sound = 'tone-1C';

pKey56 = new Object;
pKey56.kbKey = '';
pKey56.flag = true;
pKey56.value = '#1C';
pKey56.sound = 'tone-1C';

pKey57 = new Object;
pKey57.kbKey = '';
pKey57.flag = true;
pKey57.value = '#1C';
pKey57.sound = 'tone-1C';

pKey58 = new Object;
pKey58.kbKey = '';
pKey58.flag = true;
pKey58.value = '#1C';
pKey58.sound = 'tone-1C';

pKey59 = new Object;
pKey59.kbKey = '';
pKey59.flag = true;
pKey59.value = '#1C';
pKey59.sound = 'tone-1C';

pKey60 = new Object;
pKey60.kbKey = '';
pKey60.flag = true;
pKey60.value = '#0G';
pKey60.sound = 'tone-0G';

pKey61 = new Object;
pKey61.kbKey = '';
pKey61.flag = true;
pKey61.value = '#0Gs';
pKey61.sound = 'tone-0Gs';

pKey62 = new Object;
pKey62.kbKey = '';
pKey62.flag = true;
pKey62.value = '#0A';
pKey62.sound = 'tone-0A';

pKey63 = new Object;
pKey63.kbKey = '';
pKey63.flag = true;
pKey63.value = '#0As';
pKey63.sound = 'tone-0As';

pKey64 = new Object;
pKey64.kbKey = '';
pKey64.flag = true;
pKey64.value = '#0B';
pKey64.sound = 'tone-0B';

pKey65 = new Object;
pKey65.kbKey = '';
pKey65.flag = true;
pKey65.value = '#1C';
pKey65.sound = 'tone-1C';

pKey66 = new Object;
pKey66.kbKey = '';
pKey66.flag = true;
pKey66.value = '#1C';
pKey66.sound = 'tone-1C';

pKey67 = new Object;
pKey67.kbKey = '';
pKey67.flag = true;
pKey67.value = '#1C';
pKey67.sound = 'tone-1C';

pKey68 = new Object;
pKey68.kbKey = '';
pKey68.flag = true;
pKey68.value = '#1C';
pKey68.sound = 'tone-1C';

pKey69 = new Object;
pKey69.kbKey = '';
pKey69.flag = true;
pKey69.value = '#1C';
pKey69.sound = 'tone-1C';

pKey70 = new Object;
pKey70.kbKey = '';
pKey70.flag = true;
pKey70.value = '#0G';
pKey70.sound = 'tone-0G';

pKey71 = new Object;
pKey71.kbKey = '';
pKey71.flag = true;
pKey71.value = '#0Gs';
pKey71.sound = 'tone-0Gs';

pKey72 = new Object;
pKey72.kbKey = '';
pKey72.flag = true;
pKey72.value = '#0A';
pKey72.sound = 'tone-0A';

pKey73 = new Object;
pKey73.kbKey = '';
pKey73.flag = true;
pKey73.value = '#0As';
pKey73.sound = 'tone-0As';

pKey74 = new Object;
pKey74.kbKey = '';
pKey74.flag = true;
pKey74.value = '#0B';
pKey74.sound = 'tone-0B';

pKey75 = new Object;
pKey75.kbKey = '';
pKey75.flag = true;
pKey75.value = '#1C';
pKey75.sound = 'tone-1C';

pKey76 = new Object;
pKey76.kbKey = '';
pKey76.flag = true;
pKey76.value = '#1C';
pKey76.sound = 'tone-1C';

pKey77 = new Object;
pKey77.kbKey = '';
pKey77.flag = true;
pKey77.value = '#6Cs';
pKey77.sound = 'tone-6Cs';

pKey78 = new Object;
pKey78.kbKey = '*,';
pKey78.flag = true;
pKey78.value = '#6D';
pKey78.sound = 'tone-6D';

pKey79 = new Object;
pKey79.kbKey = '';
pKey79.flag = true;
pKey79.value = '#6Ds';
pKey79.sound = 'tone-6Ds';

pKey80 = new Object;
pKey80.kbKey = '';
pKey80.flag = true;
pKey80.value = '#6E';
pKey80.sound = 'tone-6E';

pKey81 = new Object;
pKey81.kbKey = '';
pKey81.flag = true;
pKey81.value = '#6F';
pKey81.sound = 'tone-6F';

pKey82 = new Object;
pKey82.kbKey = '';
pKey82.flag = true;
pKey82.value = '#6Fs';
pKey82.sound = 'tone-6Fs';

pKey83 = new Object;
pKey83.kbKey = '';
pKey83.flag = true;
pKey83.value = '#06G';
pKey83.sound = 'tone-6G';

pKey84 = new Object;
pKey84.kbKey = '';
pKey84.flag = true;
pKey84.value = '#6Gs';
pKey84.sound = 'tone-6Gs';

pKey85 = new Object;
pKey85.kbKey = '';
pKey85.flag = true;
pKey85.value = '#6A';
pKey85.sound = 'tone-6A';

pKey86 = new Object;
pKey86.kbKey = '';
pKey86.flag = true;
pKey86.value = '#6As';
pKey86.sound = 'tone-6As';

pKey87 = new Object;
pKey87.kbKey = '';
pKey87.flag = true;
pKey87.value = '#6B';
pKey87.sound = 'tone-6B';

pKey88 = new Object;
pKey88.kbKey = '';
pKey88.flag = true;
pKey88.value = '#7C';
pKey88.sound = 'tone-7C';